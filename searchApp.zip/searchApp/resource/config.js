gOptions = {
  // This can have nested stuff, arrays, etc.
  enabled: true,		
  url: 'http://127.0.01:8080/webCrawler/inbound:_httpGet?action=find'
};