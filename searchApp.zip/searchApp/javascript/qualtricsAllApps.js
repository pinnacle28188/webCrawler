<!--BEGIN QUALTRICS SITE INTERCEPT-->
var SI_9GiYyHQHuUVcha4_ed='';
var SI_9GiYyHQHuUVcha4_url='https://siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_SIID=SI_9GiYyHQHuUVcha4' + SI_9GiYyHQHuUVcha4_ed;
var SI_9GiYyHQHuUVcha4_sampleRate=100;
var q_si_f = function(){if (Math.random() >= SI_9GiYyHQHuUVcha4_sampleRate/100)return; var s=document.createElement('script');s.type='text/javascript';s.src=SI_9GiYyHQHuUVcha4_url+'&Q_LOC='+escape(window.location.href);if(document.body)document.body.appendChild(s);};try{if (window.addEventListener){window.addEventListener('load',q_si_f,false);}else if (window.attachEvent){r=window.attachEvent('onload',q_si_f);}else {}}catch(e){}

document.write("<div id='SI_9GiYyHQHuUVcha4'><!--DO NOT REMOVE-CONTENTS PLACED HERE--></div>")
<!--END SITE INTERCEPT-->
